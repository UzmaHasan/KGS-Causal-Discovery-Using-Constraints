#import sys

#sys.path.append("")
#import unittest

import time
st = time.time()

import numpy as np
import hashlib

from KGS.graph.AdjacencyConfusion import AdjacencyConfusion
from KGS.graph.ArrowConfusion import ArrowConfusion
from KGS.graph.SHD import SHD
from KGS.search.ScoreBased.KGS import kgs
from KGS.score.LocalScoreFunction import local_score_BIC
from KGS.utils.DAG2CPDAG import dag2cpdag
from KGS.utils.TXT2GeneralGraph import txt2generalgraph


#load BN datasets
data_path = "child.txt"
dataset = np.loadtxt(data_path, skiprows=1)

#load any dataset (e.g. synthetic)
dataset = np.load('data10.npy')

Record = kgs(dataset, 'local_score_BIC', None, None) 
est = Record['G']

#ground-truth 
truth_dag = txt2generalgraph("data10.graph.txt")
truth_cpdag = dag2cpdag(truth_dag)

adj = AdjacencyConfusion(truth_cpdag, est)
arrow = ArrowConfusion(truth_cpdag, est)

adjTp = adj.get_adj_tp()
adjFp = adj.get_adj_fp()
adjFn = adj.get_adj_fn()
adjTn = adj.get_adj_tn()

arrowsTp = arrow.get_arrows_tp()
arrowsFp = arrow.get_arrows_fp()
arrowsFn = arrow.get_arrows_fn()
arrowsTn = arrow.get_arrows_tn()
arrowsTpCE = arrow.get_arrows_tp_ce()
arrowsFpCE = arrow.get_arrows_fp_ce()
arrowsFnCE = arrow.get_arrows_fn_ce()
arrowsTnCE = arrow.get_arrows_tn_ce()

adjPrec = adj.get_adj_precision()
adjRec = adj.get_adj_recall()
adjFDR = adj.get_adj_FDR ()
arrowPrec = arrow.get_arrows_precision()
arrowRec = arrow.get_arrows_recall()
arrowFDR = arrow.get_arrows_FDR()
arrowPrecCE = arrow.get_arrows_precision_ce()
arrowRecCE = arrow.get_arrows_recall_ce()


print(f"ArrowsTp: {arrowsTp}")
print(f"ArrowsFp: {arrowsFp}")
print(f"ArrowsFn: {arrowsFn}")
print(f"ArrowsTn: {arrowsTn}")


print(f"ArrowPrec (Prec): {arrowPrec}")
print(f"ArrowRec(TPR): {arrowRec}")
print(f"ArrowFDR(FDR): {arrowFDR}")


shd = SHD(truth_cpdag, est)
print(f"SHD: {shd.get_shd()}")


et = time.time()
elapsed_time = et - st
print('Execution time:', elapsed_time, 'seconds')


# Visualization using pydot
from KGS.utils.GraphUtils import GraphUtils
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import io


pyd = GraphUtils.to_pydot(Record['G'], labels = ['X1','X2','X3','X4','X5','X6','X7','X8','X9','X10'])
tmp_png = pyd.create_png(f="png")
fp = io.BytesIO(tmp_png)
img = mpimg.imread(fp, format='png')
plt.axis('off')
plt.imshow(img)
plt.show()








