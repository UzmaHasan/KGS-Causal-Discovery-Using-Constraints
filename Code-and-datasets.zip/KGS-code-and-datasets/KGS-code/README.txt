The simulated datasets, real BnLearn datasets, oxygen-therapy dataset and all respective ground-truths are provided.

-------Step by step instructions to test KGS--------

1. To use KGS, please install the publicly available package causal-learn using pip:  "pip install causal-learn"

2. The main file to run KGS is the test_KGS.py where the datasets and ground truth can be loaded.

3. To use prior knowledge please refer to the KGS.py file located at:

KGS-Code\KGS\search\ScoreBased\KGS.py. 

The way to load prior knowledge is mentioned in details in that file.